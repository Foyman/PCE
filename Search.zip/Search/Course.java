package logic;

public class Course
{
	public String name;
	public int distance;
	
	public Course(String name)
	{
		this.name = name;
		this.distance = Integer.MAX_VALUE;
	}
	
}
