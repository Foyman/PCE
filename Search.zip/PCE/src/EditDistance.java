
import java.lang.Math;
import java.util.Arrays;

public class EditDistance 
{

	public static Class[] sortList(String search, String[] classesStr)
	{
		Class[] classes = new Class[classesStr.length];
		ClassComparator compare = new ClassComparator();
		int i = 0;
		for (String s: classesStr)
		{
			classes[i] = new Class(s);
			classes[i++].setDistance(getDistance(search.toLowerCase(), s.toLowerCase()));
		}
		Arrays.sort(classes, compare);
		for(Class c: classes)
		{
			System.out.println(c.getName() + " " + c.getDistance());
		}
		return classes;
	}
	
	public static int getDistance(String s1, String s2)
	{
		int len1 = s1.length() + 1;
		int len2 = s2.length() + 1;
		int[][] ED = new int[len1][len2];
		for(int i = 0; i < len1; i++)
		{
			ED[i][0] = i;
		}
		for(int j = 0; j < len2; j++)
		{
			ED[0][j] = j;
		}
		for(int i = 1; i < len1; i++)
		{
			for(int j = 1; j < len2; j++)
			{
				int min = Math.min(1 + ED[i-1][j], 1 + ED[i][j-1]);
				int x = (s1.charAt(i-1) == s2.charAt(j-1) ? 0:1);
				ED[i][j] = Math.min(min, x + ED[i-1][j-1]);
			}
		}
		return ED[len1 - 1][len2 - 1];
	}
	
}
