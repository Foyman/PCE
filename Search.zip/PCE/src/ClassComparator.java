import java.util.Comparator;

public class ClassComparator implements Comparator<Class>{

	@Override
	public int compare(Class o1, Class o2) 
	{
		if(o1.getDistance() < o2.getDistance())
			return -1;
		else
			return 1;
	}
	
}
