
public class Search {

	public static void main(String[] args)
	{
		String search = "CSC 100";
		String[] array = new String[5];
		array[0] = "BUS 100";
		array[1] = "CSC 300";
		array[2] = "CSC 307";
		array[3] = "STAT 312";
		array[4] = "csc 100";
		EditDistance.sortList(search, array);
	}
	
}
