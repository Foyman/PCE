
public class Class
{
	private String name;
	private int distance;
	
	public Class(String name)
	{
		this.name = name;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setDistance(int distance)
	{
		this.distance = distance;
	}
	
	public int getDistance()
	{
		return distance;
	}
}
